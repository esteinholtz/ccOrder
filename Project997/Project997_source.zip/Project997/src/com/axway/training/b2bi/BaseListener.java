package com.axway.training.b2bi;


public abstract class BaseListener {


}
