package com.axway.training.b2bi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Hashtable;
import java.util.Properties;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.berryworks.edireader.EDIReader;
import com.berryworks.edireader.EDIReaderFactory;
import com.berryworks.edireader.demo.EDIAck;

public class FileListener extends BaseListener implements IFileListener {

	// public static Logger log = Logger.getLogger(FileListener.class);
	private String outputDir;
	private String tempDir;
	private EDIReader parser;
	private Hashtable<String, String> docDetailsFromContentHandler;
	private String docType;
	private boolean isChecked;

	/**
	 * Connstructor
	 */
	public FileListener() {
		super();
	}

	public void onStart(Object monitoredResource) {
		// On startup
		if (monitoredResource instanceof File) {
			File resource = (File) monitoredResource;
			if (resource.isDirectory()) {

				System.out.println("Start to monitor "
						+ resource.getAbsolutePath());
				final Properties props = new Properties();
				try {
					props.load(new FileInputStream("props.properties"));

				} catch (final FileNotFoundException e) {

					System.out.println("Properties file is not found");
				} catch (final IOException e) {

					System.out
					.println(" Properties file is not pointing to a valid path");
				}

				final String dir2bMonitored = props
				.getProperty("Directory_To_Be_Monitored");
				outputDir = props.getProperty("Output_Directory");
				tempDir = props.getProperty("Temp_Directory");
				System.out.println("The dir to monitor is " + dir2bMonitored);
				System.out.println("The temporary directory is "+ tempDir);
				System.out
				.println("The dir to push the 997 acknowledgement file is "
						+ outputDir);

			}
		}
	}

	public void onStop(Object notMonitoredResource) {

	}

	/*
	 * (non-Javadoc)
	 * @see com.axway.training.b2bi.IResourceListener#onAdd(java.lang.Object)
	 * This function is customized to create a 997 acknowledgment if the added document is an EDI document.
	 */
	public void onAdd(Object newResource) {
		if (newResource instanceof File) {
			File file = (File) newResource;
			if (file.isFile()) {
				System.out.println(file.getAbsolutePath() + " is added");
				
				/*
				 * This function scans the newly added edi document and sets the edi document type.
				 */
				
				ediScan(file.getAbsolutePath());
				
				/*
				 *  This part of the code generates the EDI acknowledgement in the given output directory. 
				 */

				if (docType != null && !docType.equalsIgnoreCase("997")) {
					String tempOutputFilePath = tempDir+ "\\997_"
							+ file.getName().substring(0,file.getName().length() - 4) + ".edi";
					String finalFilePath = outputDir+ "\\997_"
					+ file.getName().substring(0,file.getName().length() - 4) + ".edi";
					EDIAck demo = new EDIAck(file.getAbsolutePath(), tempOutputFilePath,false);
					//isChecked= false;
					demo.run();
					String poNum = setPONum(file.getAbsolutePath());
					updateFile(tempOutputFilePath,finalFilePath, poNum);

				}
//					else if (docType.equalsIgnoreCase("997") && 
//						//file.getName().startsWith(prefix)substring(file.getName().length() - 7, file.getName().length()).equalsIgnoreCase(".rawedi")){
//					    file.getName().startsWith("997_")){
//					
//						updateFile(file.getAbsolutePath());
//					    
//					 
//					
//				}
			}
		}
	}
	
	private String setPONum(String absolutePath) {
		 String poNum="";
		 try {
		      //use buffering, reading one line at a time
		      //FileReader always assumes default encoding is OK!
		      BufferedReader input =  new BufferedReader(new FileReader(absolutePath));
		      try {
		        String line = null; //not declared within while loop
		       
		        /*
		        * readLine is a bit quirky :
		        * it returns the content of a line MINUS the newline.
		        * it returns null only for the END of the stream.
		        * it returns an empty String if two newlines appear in a row.
		        */
		  
		        while (( line = input.readLine()) != null){
		        	if(docType.equalsIgnoreCase("856") && line.startsWith("PRF*")){
		        		poNum = line.substring(line.indexOf("*")+1, line.length());
		        	}else if (docType.equalsIgnoreCase("810") && line.startsWith("BIG*")){
		        		String[] tempList = line.split("\\*");
		        		for(int i =0; i < tempList.length ; i++)
		        		    System.out.println(tempList[i]);
		        		poNum = tempList[4];
		        	}
		        }
		      }
		      finally {
		        input.close();
		      }
		    }
		    catch (IOException ex){
		      ex.printStackTrace();
		    }
		        System.out.println("The poNum is "+poNum);
		       
		        
		       
		return (poNum!= "")? poNum : "0001" ;
	}

	private boolean updateFile(String filePath, String finalFilePath, String poNum) {
		StringBuilder contents = new StringBuilder();
	    
	    try {
	      //use buffering, reading one line at a time
	      //FileReader always assumes default encoding is OK!
	      BufferedReader input =  new BufferedReader(new FileReader(filePath));
	      try {
	        String line = null; //not declared within while loop
	       
	        /*
	        * readLine is a bit quirky :
	        * it returns the content of a line MINUS the newline.
	        * it returns null only for the END of the stream.
	        * it returns an empty String if two newlines appear in a row.
	        */
	        
	        while (( line = input.readLine()) != null){
	        	System.out.println(line);
	        	if (line.substring(0,2).equalsIgnoreCase("ST") || line.substring(0,2).equalsIgnoreCase("SE") ){
	      		  	
	        		line = line.substring(0, line.lastIndexOf("*")+1)+poNum;
	        		//System.out.println("updated line is "+ line);
	      	  }
	          contents.append(line);
	          contents.append(System.getProperty("line.separator"));
	        }
	      }
	      finally {
	        input.close();
	      }
	    }
	    catch (IOException ex){
	      ex.printStackTrace();
	    }
	    System.out.println("final content:");
	    System.out.println();
	    System.out.println(contents.toString());
	    Writer output = null;
		try {
			
			output = new BufferedWriter(new FileWriter(finalFilePath));
			output.append(contents);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				output.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  return true;
		
	}

	

	/*
	 * This function is used to send events to sentinel monitoring plus for tracking. This function reads
	 * the sentinel server properties from sentinelprops.properties file and
	 * sends the data to it.
	 * Currently this feature is not implemented. If developer wants to implement this feature, 
	 */
//	private void sendEvents(final Hashtable<String, String> dataTable) {
//
//		// final String sentinelpropsFilePath =
//		// getInvocationParameter("sentinelprops.properties");
//		final Properties props = new Properties();
//		try {
//			props.load(new FileInputStream("sentinelprops.properties"));
//
//		} catch (final FileNotFoundException e) {
//			System.out
//			.println("Hellboy: \"sentinelprops.properties\" invocation parameter is not pointing to a valid path");
//
//		} catch (final IOException e) {
//			System.out
//			.println("Hellboy: \"sentinelprops.properties\" invocation parameter is not pointing to a valid path");
//
//		} catch (final NullPointerException e) {
//			System.out
//			.println("Hellboy: \"sentinelprops.properties\" invocation parameter is missing. "
//					+ "This parameters specifies the file path for the sentinel server and tracking object details.");
//
//		}
//
//		final String sentinelHostName = props.getProperty("Sentinel_HostName");
//		final String sentinelPortNumber = props
//		.getProperty("Sentinel_PortNumber");
//		final String trackingObject = props.getProperty("TrackingObject");
//
//		System.out.println("Hellboy: Sentinel_hostname :" + sentinelHostName
//				+ " Sentinel Portnumber :" + sentinelPortNumber
//				+ " Tracking Object :" + trackingObject);
//		final TrkApiUA trkapiua = new TrkApiUA(sentinelHostName,
//				sentinelPortNumber);
//		final TrkMessageUAEvent trkmsgevent = new TrkMessageUAEvent(trkapiua,
//				trackingObject, "1.0");
//
//		final Iterator itr = dataTable.keySet().iterator();
//		System.out
//		.println("Following are the set of the environment variables and values sent to Sentinel");
//		while (itr.hasNext()) {
//			final String key = (String) itr.next();
//			final String value = (String) dataTable.get(key);
//			trkmsgevent.setAttribute(key, value);
//			System.out.println(key + " = " + value);
//		}
//
//		trkapiua.sendMessage(trkmsgevent);
//
//	}

	public void onChange(Object changedResource) {
		if (changedResource instanceof File) {
			File file = (File) changedResource;
			if (file.isFile()) {
				System.out.println(file.getAbsolutePath() + " is changed");
			}

		}
	}

	public void onDelete(Object deletedResource) {
		if (deletedResource instanceof String) {
			String deletedFile = (String) deletedResource;
			System.out.println(deletedFile + " is deleted");
		}
	}

	/**
	 * Main processing method for the EDIScanner object
	 */
	public void ediScan(String inputFileName) {

		ContentHandler handler = new ScanningHandler();
		InputSource inputSource = null;

		if (inputFileName != null) {
			try {
				inputSource = new InputSource(new FileReader(inputFileName));
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}
		}

		try {
			while (true) {
				// The following line creates an EDIReader explicitly
				// as an alternative to the JAXP-based technique.
				parser = EDIReaderFactory.createEDIReader(inputSource);
				if (parser == null) {
					// end of input
					break;
				}
				parser.setContentHandler(handler);
				parser.parse(inputSource);
			}

			docType = ((ScanningHandler) handler).getDocType();
			System.out.println("The document type is " + docType);

		} catch (IOException e) {
			e.printStackTrace();

		} catch (SAXException e) {
			System.out.println("\nEDI input not well-formed:\n");
			// e.printStackTrace();

		}
	}

	class ScanningHandler extends DefaultHandler {
		int interchangeCount = 0;
		public String documentType;
		
		
		public Hashtable<String, String> documentDetails = new Hashtable<String, String>();
		boolean isSender = false;

		/**
		 * Description of the Method
		 * 
		 * @param namespace
		 *            Description of the Parameter
		 * @param localName
		 *            Description of the Parameter
		 * @param qName
		 *            Description of the Parameter
		 * @param atts
		 *            Description of the Parameter
		 * @exception SAXException
		 *                Description of the Exception
		 */
		public void startElement(String namespace, String localName,
				String qName, Attributes atts) throws SAXException {
			
			/*
			 * The commented part of the code is used to create a hash table of data to be sent 
			 * to Sentinel server
			 */

						//			System.out.println(" LocalName: " + localName + " qName: " + qName);
						//			DateFormat df = new SimpleDateFormat("yyMMdd");
						//			DateFormat gpDate = new SimpleDateFormat("yyyyMMdd");
						//			DateFormat time = new SimpleDateFormat("HHmm");
						//			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						//			SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
						//
						//			if (localName.equalsIgnoreCase("interchange")) {
						//
						//				try {
						//					System.out.println("Date: "
						//							+ dateFormat
						//							.format(df.parse(atts.getValue("Date"))));
						//					System.out.println("Time: "
						//							+ timeFormat.format(time.parse(atts
						//									.getValue("Time"))));
						//
						//					documentDetails.put("ISADt", dateFormat.format(df
						//							.parse(atts.getValue("Date"))));
						//					documentDetails.put("ISATime", timeFormat.format(time
						//							.parse(atts.getValue("Time"))));
						//					documentDetails.put("ISAControlNum", atts
						//							.getValue("Control"));
						//
						//				} catch (ParseException e) {
						//					// TODO Auto-generated catch block
						//					e.printStackTrace();
						//				}
						//			} else if (localName.equalsIgnoreCase("sender")) {
						//				isSender = true;
						//			} else if (localName.equalsIgnoreCase("address") && isSender) {
						//				System.out.println("Sender id is " + atts.getValue("Qual")
						//						+ "," + atts.getValue("Id"));
						//				documentDetails.put("ISASenderID", atts.getValue("Qual") + ","
						//						+ atts.getValue("Id"));
						//				isSender = false;
						//			} else if (localName.equalsIgnoreCase("address") && !isSender) {
						//				System.out.println("Receiver id is " + atts.getValue("Qual")
						//						+ "," + atts.getValue("Id"));
						//				documentDetails.put("ISAReceiverID", atts.getValue("Qual")
						//						+ "," + atts.getValue("Id"));
						//			} else if (localName.equalsIgnoreCase("group")) {
						//				try {
						//					System.out.println("Date: "
						//							+ dateFormat.format(gpDate.parse(atts
						//									.getValue("Date"))));
						//					System.out.println("Time: "
						//							+ timeFormat.format(time.parse(atts
						//									.getValue("Time"))));
						//
						//					documentDetails.put("GSDate", dateFormat.format(gpDate
						//							.parse(atts.getValue("Date"))));
						//					documentDetails.put("GSTime", timeFormat.format(time
						//							.parse(atts.getValue("Time"))));
						//					documentDetails.put("GSControlNum", atts
						//							.getValue("Control"));
						//
						//				} catch (ParseException e) {
						//					// TODO Auto-generated catch block
						//					e.printStackTrace();
						//				}
						//
						//			}

			int n = atts.getLength();
			for (int i = 0; i < n; i++) {
				System.out.println(atts.getLocalName(i) + "=" + atts.getValue(i));
				if (atts.getLocalName(i).equalsIgnoreCase("DocType"))
					documentType = atts.getValue(i);
			}
		}

		public Hashtable<String, String> getDocDetails() {

			return documentDetails;
		}

		public String getDocType() {
			return documentType;
		}
	}
}
