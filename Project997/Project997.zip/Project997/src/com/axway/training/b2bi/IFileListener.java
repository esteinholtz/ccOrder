package com.axway.training.b2bi;

public interface IFileListener extends IResourceListener {

   
}